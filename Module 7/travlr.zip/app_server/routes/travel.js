var express = require('express');
var router = express.Router();
var ctrlTravel = require('../controllers/travel');

/* GET travel view. */
router.get('/', ctrlTravel.travel);

module.exports = router;
