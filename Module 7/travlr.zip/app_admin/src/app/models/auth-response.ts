export class AuthResponse {
  token = '';
}
